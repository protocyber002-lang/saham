# Core\Server.ps1
$listener = New-Object System.Net.HttpListener
$listener.Prefixes.Add("http://+:8889/") # Atau http://192.168.0.100:8889/
$listener.Start()
Write-Host "Server berjalan di http://192.168.0.100:8889/"

while ($listener.IsListening) {
    $context = $listener.GetContext()
    $request = $context.Request
    $response = $context.Response

    # CORS (Agar PWA bisa akses)
    $response.AddHeader("Access-Control-Allow-Origin", "*")
    $response.AddHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
    
    if ($request.HttpMethod -eq "OPTIONS") {
        $response.StatusCode = 200
        $response.Close()
        continue
    }

    $path = $request.Url.LocalPath
    $data = ""

    if ($path -eq "/api/stocks") {
        # Kirim data saham
        $data = [System.IO.File]::ReadAllText("D:\powershell\ClickTycoonIdle\Data\stocks.json")
        $response.ContentType = "application/json"
    }
    elseif ($path -eq "/api/buy") {
        # Logika Beli (Baca Query: ?ticker=AAPL&qty=10)
        # ... (nanti kita buat) ...
        $data = '{"status":"ok"}'
    }

    $buffer = [System.Text.Encoding]::UTF8.GetBytes($data)
    $response.ContentLength64 = $buffer.Length
    $response.OutputStream.Write($buffer, 0, $buffer.Length)
    $response.Close()
}